/*********************************************************************
This library is inspired by the Adafruit_SSD1306 library from Adafruit
written by Limor Fried/Ladyada  for Adafruit Industries. The original 
library is BSD licensed.

Just like SKAARHOJ, Adafruit also invests time and resources providing 
open source code, so SKAARHOJ encourage you to support Adafruit and 
open-source hardware by purchasing products from Adafruit as well!
*********************************************************************/

#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdlib.h>

#include <Wire.h>

#include "Adafruit_GFX.h"
#include "SkaarhojDisplayArray.h"


// The memory buffer for the LCD
static uint8_t buffer[SKAARHOJDISPARRAY_LCDHEIGHT * SKAARHOJDISPARRAY_LCDWIDTH / 8];

// The most basic function, set a single pixel
void SkaarhojDisplayArray::drawPixel(int16_t x, int16_t y, uint16_t color) {
  if ((x < 0) || (x >= width()) || (y < 0) || (y >= height()))
    return;

  // check rotation, move pixel around if necessary
  switch (getRotation()) {
  case 1:
    swap(x, y);
    x = WIDTH - x - 1;
    break;
  case 2:
    x = WIDTH - x - 1;
    y = HEIGHT - y - 1;
    break;
  case 3:
    swap(x, y);
    y = HEIGHT - y - 1;
    break;
  }  

  // x is which column
  if (color == WHITE) 
    buffer[x+ (y/8)*SKAARHOJDISPARRAY_LCDWIDTH] |= _BV((y%8));  
  else
    buffer[x+ (y/8)*SKAARHOJDISPARRAY_LCDWIDTH] &= ~_BV((y%8)); 
}

// Empty constructor.
SkaarhojDisplayArray::SkaarhojDisplayArray() : Adafruit_GFX(SKAARHOJDISPARRAY_LCDWIDTH, SKAARHOJDISPARRAY_LCDHEIGHT) {}		


void SkaarhojDisplayArray::begin(uint8_t address) {
	// NOTE: Wire.h should definitely be initialized at this point! (Wire.begin())

	_boardAddress = 0x20 | (address & B111);	// 0-7

  	// Set SPI pins up:
	_clockPin = 48;
	_dataPin = 49;

	pinMode(_clockPin, OUTPUT);
	pinMode(_dataPin, OUTPUT);

    clkport     = portOutputRegister(digitalPinToPort(_clockPin));
    clkpinmask  = digitalPinToBitMask(_clockPin);
    mosiport    = portOutputRegister(digitalPinToPort(_dataPin));
    mosipinmask = digitalPinToBitMask(_dataPin);

	// Control pins:
	_cs = 0;
	_dc = false;
	_rst = true;
	writeControlPins();
  	delay(1);

  	// bring reset low
	_rst = false;
	writeControlPins();
  	// wait 10ms
  	delay(10);
  	// bring out of reset
	_rst = true;
	writeControlPins();
  	// turn on VCC (9V?)


    // Init sequence for 128x32 OLED module
	uint8_t vccstate = SSD1306_SWITCHCAPVCC;

	uint8_t cs = B1111;

    ssd1306_command(SSD1306_DISPLAYOFF, cs);                    // 0xAE
    ssd1306_command(SSD1306_SETDISPLAYCLOCKDIV, cs);            // 0xD5
    ssd1306_command(0x80, cs);                                  // the suggested ratio 0x80
    ssd1306_command(SSD1306_SETMULTIPLEX, cs);                  // 0xA8
    ssd1306_command(0x1F, cs);
    ssd1306_command(SSD1306_SETDISPLAYOFFSET, cs);              // 0xD3
    ssd1306_command(0x0, cs);                                   // no offset
    ssd1306_command(SSD1306_SETSTARTLINE | 0x0, cs);            // line #0
    ssd1306_command(SSD1306_CHARGEPUMP, cs);                    // 0x8D
    if (vccstate == SSD1306_EXTERNALVCC) 
      { ssd1306_command(0x10, cs); }
    else 
      { ssd1306_command(0x14, cs); }
    ssd1306_command(SSD1306_MEMORYMODE, cs);                    // 0x20
    ssd1306_command(0x00, cs);                                  // 0x0 act like ks0108
	ssd1306_command(SSD1306_SEGREMAP | 0x1, cs);
    ssd1306_command(SSD1306_COMSCANDEC, cs);
    ssd1306_command(SSD1306_SETCOMPINS, cs);                    // 0xDA
    ssd1306_command(0x02, cs);
    ssd1306_command(SSD1306_SETCONTRAST, cs);                   // 0x81
    ssd1306_command(0x8F, cs);
    ssd1306_command(SSD1306_SETPRECHARGE, cs);                  // 0xd9
    if (vccstate == SSD1306_EXTERNALVCC) 
      { ssd1306_command(0x22, cs); }
    else 
      { ssd1306_command(0xF1, cs); }
    ssd1306_command(SSD1306_SETVCOMDETECT, cs);                 // 0xDB
    ssd1306_command(0x40, cs);
    ssd1306_command(SSD1306_DISPLAYALLON_RESUME, cs);           // 0xA4
    ssd1306_command(SSD1306_NORMALDISPLAY, cs);                 // 0xA6

  
  ssd1306_command(SSD1306_DISPLAYON, cs);//--turn on oled panel
}


void SkaarhojDisplayArray::ssd1306_command(uint8_t c, uint8_t cs) { 

	chipSelect(0);
	setDC(false);
	chipSelect(cs);
	
    fastSPIwrite(c);

	chipSelect(0);
}
void SkaarhojDisplayArray::ssd1306_data(uint8_t c, uint8_t cs) {

	chipSelect(0);
	setDC(true);
	chipSelect(cs);
	
    fastSPIwrite(c);

	chipSelect(0);
}

// clear everything
void SkaarhojDisplayArray::clearDisplay(void) {
  memset(buffer, 0, (SKAARHOJDISPARRAY_LCDWIDTH*SKAARHOJDISPARRAY_LCDHEIGHT/8));
}

void SkaarhojDisplayArray::invertDisplay(bool i, uint8_t cs) {
  if (i) {
    ssd1306_command(SSD1306_INVERTDISPLAY, cs);
  } else {
    ssd1306_command(SSD1306_NORMALDISPLAY, cs);
  }
}

void SkaarhojDisplayArray::display(uint8_t cs) {
  ssd1306_command(SSD1306_SETLOWCOLUMN | 0x0, cs);  // low col = 0
  ssd1306_command(SSD1306_SETHIGHCOLUMN | 0x0, cs);  // hi col = 0
  ssd1306_command(SSD1306_SETSTARTLINE | 0x0, cs); // line #0

    // SPI
	chipSelect(0);
	setDC(true);
	chipSelect(cs);
	
    for (uint16_t i=0; i<(SKAARHOJDISPARRAY_LCDWIDTH*SKAARHOJDISPARRAY_LCDHEIGHT/8); i++) {
      fastSPIwrite(buffer[i]);
    }
    // i wonder why we have to do this (check datasheet)
    if (SKAARHOJDISPARRAY_LCDHEIGHT == 32) {
      for (uint16_t i=0; i<(SKAARHOJDISPARRAY_LCDWIDTH*SKAARHOJDISPARRAY_LCDHEIGHT/8); i++) {
        fastSPIwrite(0);
      }
    }

	chipSelect(0);
}

inline void SkaarhojDisplayArray::fastSPIwrite(uint8_t d) {
  for(uint8_t bit = 0x80; bit; bit >>= 1) {
    *clkport &= ~clkpinmask;
    if(d & bit) *mosiport |=  mosipinmask;
    else        *mosiport &= ~mosipinmask;
    *clkport |=  clkpinmask;
  }
}

void SkaarhojDisplayArray::chipSelect(uint8_t cs) {
	_cs = cs;
	writeControlPins();
}

void SkaarhojDisplayArray::setDC(bool dc) {
	_dc = dc;
	writeControlPins();
}

void SkaarhojDisplayArray::writeControlPins() {
  Wire.beginTransmission(_boardAddress);
  Wire.write(((uint8_t)~_cs));
  Wire.write((_rst << 7) | (_dc << 6));
  Wire.endTransmission();
/*
  delay(100);
  Wire.requestFrom(0x20, 2);  // asking for two bytes - could ask for more, would just get the same data again.

	while(Wire.available())
	  { 
		Serial.println(Wire.read(),BIN);
	  }

  Serial.println("---");
  delay(2000);
*/
}




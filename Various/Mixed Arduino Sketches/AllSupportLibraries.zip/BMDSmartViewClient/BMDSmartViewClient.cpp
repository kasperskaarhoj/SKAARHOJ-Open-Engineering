/*
Copyright 2013 Kasper Skårhøj, SKAARHOJ, kasperskaarhoj@gmail.com

This file is part of the Blackmagic Design SmartView Client library for Arduino

The BMDSmartViewClient library is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by the 
Free Software Foundation, either version 3 of the License, or (at your 
option) any later version.

The BMDSmartViewClient library is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along 
with the BMDSmartViewClient library. If not, see http://www.gnu.org/licenses/.

*/


#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif


#include "BMDSmartViewClient.h"


/**
 * Constructor (using arguments is deprecated! Use begin() instead)
 */
BMDSmartViewClient::BMDSmartViewClient(){}


/**
 * Setting up IP address for the videohub (and local port to open telnet connection to)
 */
void BMDSmartViewClient::begin(IPAddress ip){

	// Initialize the Ethernet client library
	EthernetClient client;
	_client = client;
	
	_videoHubIP = ip;	// Set SmartView IP address
	_localPort = 9992;	// Set local port
	
	_serialOutput = false;

	memset(_linebuffer,0,BMDSmartViewClient_BUFFERSIZE);
	_linebufferPointer = 0;
	
	_reconnectInterval = 5000;
	_lastReconnectAttempt = 0;
	_lastIncomingMsg = 0;
	_ackMsgInterval = 5000;
	
	_section = 0;
	
	_devicePresent = false;
	
	_isReady = false;

		// Resetting device state variables:
	_Smart_scopeMode[0] = 0;
	_Smart_scopeMode[1] = 0;
}

/**
 * Initiating connection handshake to the SmartView
 */
void BMDSmartViewClient::connect() {

  if (_serialOutput) Serial.print(F("Connecting to SmartView... "));

  // if you get a connection, report back via serial:
  if (_client.connect(_videoHubIP, _localPort)) {
	_devicePresent = true;
    if (_serialOutput) Serial.println(F("connected"));
  } else {
    // if you didn't get a connection to the server:
    if (_serialOutput) Serial.println(F("connection failed"));
	_devicePresent = false;
	_lastReconnectAttempt = millis();
  }
}

/**
 * Closing connection to SmartView
 */
void BMDSmartViewClient::disconnect() {
	_devicePresent = false;
	if (_serialOutput) Serial.println();
	if (_serialOutput) Serial.println(F("Disconnected from SmartView. Stopping client."));
	_client.stop();
	_lastReconnectAttempt = millis();
}

/**
 * Reads information from the SmartView as it arrives, does the parsing, stores in memory
 */
void BMDSmartViewClient::runLoop() {
	runLoop(0);
}
void BMDSmartViewClient::runLoop(uint16_t delayTime) {

	unsigned long enterTime = millis();

	do {
	 	// if there are incoming bytes available 
		// from the server, read them and process them:
		if (_client.connected()) {
			while (_client.available()) {
				char c = _client.read();

				if (c==10)	{	// Line break:
					_parseline();
					_resetLineBuffer();
				} else if (_linebufferPointer<BMDSmartViewClient_BUFFERSIZE-1)	{	// one byte for null termination
					_linebuffer[_linebufferPointer] = c;
					_linebufferPointer++;
				} else {
					if (_serialOutput)	Serial.println(F("ERROR: Buffer overflow."));
				}
			}
/*		
				// Request an acknowledge message:
			if (hasTimedOut(_lastIncomingMsg,_ackMsgInterval) && _isReady)	{
				setBorder(0, getBorder(0));	// Unfortunately there is no "PING" command on this protocol, so we just set a random of the parameters to its current value to provoke an "ACK" in return.
			}
				// Disconnect if no answer 2000 ms later:
			if (hasTimedOut(_lastIncomingMsg,_ackMsgInterval+2000))	{	// Has 2 seconds to respond, otherwise we disconnect to initiate a reconnect...
				disconnect();
			}
*/		}

	
		// if the server's disconnected, stop the client:
		// ACTUALLY: _client.connected() returns true EVEN if I remove the cable! So what use is it??? None... (aug. 2013)
		if (!_client.connected()) {
			if (_devicePresent)	{
				disconnect();
			} else {
				if (hasTimedOut(_lastReconnectAttempt,_reconnectInterval))	{
					connect();
				}
			}
		}
	} while (delayTime>0 && !hasTimedOut(enterTime,delayTime));
}

/**
 * Returns true if the SmartView is ready to receive a command (otherwise it is waiting for an answer to a previous command)
 */
bool BMDSmartViewClient::isReady()	{
	return _isReady;
}

/**
 * Calls runLoop until the _isReady flag has been set - or until delayTime has passed (if delay time is larger than 0 in which case it never times out)
 */
bool BMDSmartViewClient::waitForReady(uint16_t delayTime)	{
	unsigned long enterTime = millis();

	while (!_isReady && (delayTime==0 || !hasTimedOut(enterTime,delayTime)))	{
		runLoop();
	}
	
	return _isReady;
}

/**
* Calls runLoop until the _isReady flag has been set - or until 100 ms has passed. Returns the value of _isReady
 */
bool BMDSmartViewClient::waitForReady()	{
	return waitForReady(100);
}

/**
 * Returns true if the SmartView is connected
 */
bool BMDSmartViewClient::isConnected()	{
	return _devicePresent;
}

/**
 * Setter method: If _serialOutput is set, the library may use Serial.print() to give away information about its operation - mostly for debugging.
 */
void BMDSmartViewClient::serialOutput(boolean serialOutput) {
	_serialOutput = serialOutput;
}

/**
 * Timeout check
 */
bool BMDSmartViewClient::hasTimedOut(unsigned long time, unsigned long timeout)  {
  if ((unsigned long)(time + timeout) <= (unsigned long)millis())  {  // This should "wrap around" if time+timout is larger than the size of unsigned-longs, right?
    return true; 
  } 
  else {
    return false;
  }
}

/**
 * Resets internal variables. Called after reception of data to confirm, that we are ready to send a new command and there was activity on the connection.
 */
void BMDSmartViewClient::_resetLastIncomingMsg()	{
  _lastIncomingMsg = millis();
  _isReady = true;
}

/**
 * Parses a line from client
 */
void BMDSmartViewClient::_parseline()	{
	
	if (!strcmp(_linebuffer,""))	{
		_section = 0;
	} else if (!strcmp_P(_linebuffer,PSTR("PROTOCOL PREAMBLE:")))	{		//strcmp_P("RAM STRING", PSTR("FLASH STRING"));
		_section = 1;
	} else if (!strcmp_P(_linebuffer,PSTR("SMARTVIEW DEVICE:")))	{
		_section = 2;
	} else if (!strcmp_P(_linebuffer,PSTR("NETWORK:")))	{
		_section = 3;
	} else if (!strcmp_P(_linebuffer,PSTR("MONITOR A:")))	{
		_section = 4;
	} else if (!strcmp_P(_linebuffer,PSTR("MONITOR B:")))	{
		_section = 5;
	} else {

		_linebufferParsePointer = 0;

		switch(_section)	{
			case 4: 	// Monitor A or B:
			case 5:
				if (_isFirstPartOfLinebuffer_P(PSTR("Brightness:")))	{
					_linebufferParsePointer+=11+1;
					_Smart_brightness[_section-4] = _parseInt();
				}
				
				if (_isFirstPartOfLinebuffer_P(PSTR("Contrast:")))	{
					_linebufferParsePointer+=9+1;
					_Smart_contrast[_section-4] = _parseInt();
				}
				
				if (_isFirstPartOfLinebuffer_P(PSTR("Saturation:")))	{
					_linebufferParsePointer+=11+1;
					_Smart_saturation[_section-4] = _parseInt();
				}

				if (_isFirstPartOfLinebuffer_P(PSTR("Identify:")))	{
					_linebufferParsePointer+=9+1;
					if (_isFirstPartOfLinebuffer_P(PSTR("true")))	{
						_Smart_identify[_section-4] = true;
					} else {
						_Smart_identify[_section-4] = false;
					}
				}

				if (_isFirstPartOfLinebuffer_P(PSTR("Border:")))	{
					_linebufferParsePointer+=7+1;
					if (_isFirstPartOfLinebuffer_P(PSTR("None")))	{
						_Smart_border[_section-4] = 0;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Red")))	{
						_Smart_border[_section-4] = 1;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Green")))	{
						_Smart_border[_section-4] = 2;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Blue")))	{
						_Smart_border[_section-4] = 3;
/*					} else if (_isFirstPartOfLinebuffer_P(PSTR("White")))	{	// Doesn't work yet?
						_Smart_border[_section-4] = 4;
*/					} else {
						_Smart_border[_section-4] = 255;
					}
				}

				if (_isFirstPartOfLinebuffer_P(PSTR("WidescreenSD:")))	{
					_linebufferParsePointer+=13+1;
					if (_isFirstPartOfLinebuffer_P(PSTR("auto")))	{
						_Smart_widescreenSD[_section-4] = 0;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("on")))	{
						_Smart_widescreenSD[_section-4] = 1;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("off")))	{
						_Smart_widescreenSD[_section-4] = 2;
					} else {
						_Smart_widescreenSD[_section-4] = 255;
					}
				}

				if (_isFirstPartOfLinebuffer_P(PSTR("ScopeMode:")))	{
					_linebufferParsePointer+=10+1;
					if (_isFirstPartOfLinebuffer_P(PSTR("Picture")))	{
						_Smart_scopeMode[_section-4] = 0;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("AudioDbfs")))	{
						_Smart_scopeMode[_section-4] = 1;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("AudioDbvu")))	{
						_Smart_scopeMode[_section-4] = 2;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Histogram")))	{
						_Smart_scopeMode[_section-4] = 3;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("ParadeRGB")))	{
						_Smart_scopeMode[_section-4] = 4;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("ParadeYUV")))	{
						_Smart_scopeMode[_section-4] = 5;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Vector100")))	{
						_Smart_scopeMode[_section-4] = 6;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("Vector75")))	{
						_Smart_scopeMode[_section-4] = 7;
					} else if (_isFirstPartOfLinebuffer_P(PSTR("WaveformLuma")))	{
						_Smart_scopeMode[_section-4] = 8;
					} else {
						_Smart_scopeMode[_section-4] = 255;
					}
				}
				
				if (_isFirstPartOfLinebuffer_P(PSTR("AudioChannel:")))	{
					_linebufferParsePointer+=13+1;
					_Smart_audioChannel[_section-4] = _parseInt();
				}
			break;
		}
	}
	
		// Content parsing:
	if (_serialOutput) Serial.print(_section);
	if (_serialOutput) Serial.print(F(": "));
	if (_serialOutput) Serial.println(_linebuffer);
	
	_resetLastIncomingMsg();
}

/**
 * Parses the next part of string as an integer
 */
int BMDSmartViewClient::_parseInt()	{
	int output = -1;
	while(_linebufferParsePointer < _linebufferPointer)	{
		if (_linebuffer[_linebufferParsePointer]>=48 && _linebuffer[_linebufferParsePointer]<=57)	{
			if (output==-1)	output=0;
			output = output*10 +_linebuffer[_linebufferParsePointer]-48;
		} else break;
		_linebufferParsePointer++;
	}
	return output;
}

/**
 * Checks if first part of line buffer equals input string
 */
bool BMDSmartViewClient::_isFirstPartOfLinebuffer_P(const char *firstPartStr)	{
/*	uint8_t val;
	uint8_t i=0;
	while (true) {
		val = pgm_read_byte(firstPartStr);
		if (!val) break;
		if (_linebufferParsePointer+i >= _linebufferPointer || val!=_linebuffer[_linebufferParsePointer+i])	{
			return false;
		}
		i++;	
		firstPartStr++;
	}*/

	if (strncmp_P(_linebuffer+_linebufferParsePointer, firstPartStr, strlen_P(firstPartStr)))	{return false;}
	return true;
}

/**
 * Sending a command to SmartView
 */
void BMDSmartViewClient::_sendCmdRequest(uint8_t monId, const char *str)	{
	_sendCmdRequest(monId, str, String(""));
}

/**
 * Sends a command request
 * Notice that str is in PROGMEM (pass string wrapped in PSTR("")) and command is a String object (useful for variable data, but more memory intensive.)
 */
void BMDSmartViewClient::_sendCmdRequest(uint8_t monId, const char *str, const String command) {
	_isReady = false;

	_resetLineBuffer();
	_addToLineBuffer_P(PSTR("MONITOR "));
	_addToLineBuffer_P(monId==0?PSTR("A:\n"):PSTR("B:\n"));
	_addToLineBuffer_P(str);
	_addToLineBuffer(command);
	_addToLineBuffer_P(PSTR("\n\n"));

	_client.print(_linebuffer);
	if (_serialOutput) Serial.println(_linebuffer);
	
	_resetLineBuffer();
}

/**
 * Adds the input String object to linebuffer (if it has space for it)
 */
void BMDSmartViewClient::_addToLineBuffer(const String command) {
	if (_linebufferPointer+command.length()<BMDSmartViewClient_BUFFERSIZE)	{
		command.toCharArray(_linebuffer+_linebufferPointer, command.length()+1);
		_linebufferPointer+=command.length();
	} else Serial.println(F("_addToLineBuffer ERROR"));
}

/**
 * Adds the input PROGMEM string reference to linebuffer (if it has space for it)
 */
void BMDSmartViewClient::_addToLineBuffer_P(const char *str) {	// PROGMEM pointer
	if (_linebufferPointer+strlen_P(str)<BMDSmartViewClient_BUFFERSIZE)	{
		strcpy_P(_linebuffer+_linebufferPointer, str);
		_linebufferPointer+=strlen_P(str);
	} else Serial.println(F("_addToLineBuffer_P ERROR"));

/*  uint8_t val;
  while (true) {
    val = pgm_read_byte(str);
    if (!val) break;
	if (_linebufferPointer<BMDSmartViewClient_BUFFERSIZE-1)	{
		_linebuffer[_linebufferPointer] = val;
		_linebufferPointer++;
	}
    str++;
  }
*/
}

/**
 * Resets the line buffer, sets it to zeros all through.
 */
void BMDSmartViewClient::_resetLineBuffer()	{
	memset(_linebuffer,0,BMDSmartViewClient_BUFFERSIZE);
	_linebufferPointer=0;
}

void BMDSmartViewClient::printStateToSerial()	{
	for(uint8_t monId=0; monId<=1; monId++)	{
		Serial.print(F("Monitor "));
		Serial.println(monId==0?F("A:"):F("B:"));
		
		Serial.print(F("Brightness: "));
		Serial.println(getBrightness(monId));

		Serial.print(F("Contrast: "));
		Serial.println(getContrast(monId));

		Serial.print(F("Saturation: "));
		Serial.println(getSaturation(monId));

		Serial.print(F("Identify: "));
		Serial.println(getIdentify(monId));

		Serial.print(F("Border: "));
		Serial.println(getBorder(monId));

		Serial.print(F("WidescreenSD: "));
		Serial.println(getWidescreenSD(monId));

		Serial.print(F("ScopeMode: "));
		Serial.println(getScopeMode(monId));

		Serial.print(F("AudioChannel: "));
		Serial.println(getAudioChannel(monId));
		
		Serial.println();
	}
}












/**************************************
 *
 * State getter and setters. Public.
 *
 **************************************/


uint8_t BMDSmartViewClient::getBrightness(uint8_t monId) {
	return _Smart_brightness[monId];
}
void BMDSmartViewClient::setBrightness(uint8_t monId, uint8_t brightness) {
	if (monId<=1)	{
		_Smart_brightness[monId] = brightness;
		_sendCmdRequest(monId, PSTR("Brightness: "),String(brightness));
	}
}

uint8_t BMDSmartViewClient::getContrast(uint8_t monId) {
	return _Smart_contrast[monId];
}
void BMDSmartViewClient::setContrast(uint8_t monId, uint8_t contrast) {		// 127 is normal
	if (monId<=1)	{
		_Smart_contrast[monId] = contrast;
		_sendCmdRequest(monId, PSTR("Contrast: "),String(contrast));
	}
}

uint8_t BMDSmartViewClient::getSaturation(uint8_t monId) {
	return _Smart_saturation[monId];
}
void BMDSmartViewClient::setSaturation(uint8_t monId, uint8_t saturation) {		// 127 is normal
	if (monId<=1)	{
		_Smart_saturation[monId] = saturation;
		_sendCmdRequest(monId, PSTR("Saturation: "),String(saturation));
	}	
}

/**
 * Returns the identify state of monitor monID (0=A, 1=B)
 */
bool BMDSmartViewClient::getIdentify(uint8_t monId)	{
	return _Smart_identify[monId];
}

/**
 * Sets the scope mode of monitor monID (0=A, 1=B)
 */
void BMDSmartViewClient::setIdentify(uint8_t monId, bool identify)	{
	if (monId<=1)	{
		_Smart_identify[monId] = identify;
		
		if (identify)	{
			_sendCmdRequest(monId, PSTR("Identify: true"));
		} else {
			_sendCmdRequest(monId, PSTR("Identify: false"));
		}
	}
}

uint8_t BMDSmartViewClient::getBorder(uint8_t monId) {
	return _Smart_border[monId];
}
void BMDSmartViewClient::setBorder(uint8_t monId, uint8_t border) {
	if (border<=3 && monId<=1)	{
		_Smart_border[monId] = border;
		
		switch(border)	{
			case 0:
				_sendCmdRequest(monId, PSTR("Border: None"));
			break;
			case 1:
				_sendCmdRequest(monId, PSTR("Border: Red"));
			break;
			case 2:
				_sendCmdRequest(monId, PSTR("Border: Green"));
			break;
			case 3:
				_sendCmdRequest(monId, PSTR("Border: Blue"));
			break;
/*			case 4: // Not functional yet
				_sendCmdRequest(monId, PSTR("Border: White"));
			break;*/
		}	
	}	
}

uint8_t BMDSmartViewClient::getWidescreenSD(uint8_t monId) {
	return _Smart_widescreenSD[monId];
}
void BMDSmartViewClient::setWidescreenSD(uint8_t monId, uint8_t widescreenSD) {
	if (widescreenSD<=2 && monId<=1)	{
		_Smart_widescreenSD[monId] = widescreenSD;
		
		switch(widescreenSD)	{
			case 0:
				_sendCmdRequest(monId, PSTR("WidescreenSD: auto"));
			break;
			case 1:
				_sendCmdRequest(monId, PSTR("WidescreenSD: on"));
			break;
			case 2:
				_sendCmdRequest(monId, PSTR("WidescreenSD: off"));
			break;
		}	
	}
}

/**
 * Returns the scope mode of monitor monID (0=A, 1=B)
 */
uint8_t BMDSmartViewClient::getScopeMode(uint8_t monId)	{
	return _Smart_scopeMode[monId];
}

/**
 * Sets the scope mode of monitor monID (0=A, 1=B)
 */
void BMDSmartViewClient::setScopeMode(uint8_t monId, uint8_t ScopeModeIndex)	{
	if (ScopeModeIndex<=8 && monId<=1)	{
		_Smart_scopeMode[monId] = ScopeModeIndex;
		
		switch(ScopeModeIndex)	{
			case 0:
				_sendCmdRequest(monId, PSTR("ScopeMode: Picture"));
			break;
			case 1:
				_sendCmdRequest(monId, PSTR("ScopeMode: AudioDbfs"));
			break;
			case 2:
				_sendCmdRequest(monId, PSTR("ScopeMode: AudioDbvu"));
			break;
			case 3:
				_sendCmdRequest(monId, PSTR("ScopeMode: Histogram"));
			break;
			case 4:
				_sendCmdRequest(monId, PSTR("ScopeMode: ParadeRGB"));
			break;
			case 5:
				_sendCmdRequest(monId, PSTR("ScopeMode: ParadeYUV"));
			break;
			case 6:
				_sendCmdRequest(monId, PSTR("ScopeMode: Vector100"));
			break;
			case 7:
				_sendCmdRequest(monId, PSTR("ScopeMode: Vector75"));
			break;
			case 8:
				_sendCmdRequest(monId, PSTR("ScopeMode: WaveformLuma"));
			break;
		}	
	}
}

uint8_t BMDSmartViewClient::getAudioChannel(uint8_t monId) {
	return _Smart_audioChannel[monId];
}

void BMDSmartViewClient::setAudioChannel(uint8_t monId, uint8_t audioChannel) {
	if (audioChannel<=7 && monId<=1)	{
		_Smart_audioChannel[monId] = audioChannel;
		_sendCmdRequest(monId, PSTR("AudioChannel: "),String(audioChannel));
	}
}

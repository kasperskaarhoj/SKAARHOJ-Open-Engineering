/**
 * Hardware setup, config mode and preset settings
 */
void HWcfgDisplay()	{
    Serial << F("SK_MODEL: SK_DUMMY\n");
}

/**
 * Hardware setup, config mode and preset settings
 */
uint8_t HWsetupL()	{
    Serial << F("No hardware set up\n");
	return 0;
}

/**
 * Hardware test
 */
void HWtestL()	{
}

/**
 * Hardware runloop
 */
void HWrunLoop()	{
}

